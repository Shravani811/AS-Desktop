package com.automic.dac.asdesktop.errormessage;
/**
*
*
* @author Nischala 
*/
public class HomePageResponseMessage {
	 private  String message;
	 /**
	  *
	  *
	  * HomePageResponseMessage
	  */
	  public HomePageResponseMessage(String message) {
	    this.message = message;
	  }

	  public String getMessage() {
	    return message;
	  }
	  /**
	  *
	  *
	  * setMessage
	  */
	  public void setMessage(final String message) {
	    this.message = message;
	  }

	}