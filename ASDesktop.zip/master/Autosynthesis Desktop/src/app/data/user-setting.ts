export interface UserSetting{
    clientID: string;
    userID: string;
    password:string;
    checkbox: boolean;
}
export interface UserForm{
    groupname:string;
    splitno:string;
}