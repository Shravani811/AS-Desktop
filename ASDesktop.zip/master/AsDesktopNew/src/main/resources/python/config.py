desc = 'TicketDesc' #text column 
num = 25 #slect number of Top Keywords
Ngram = 3 # number of grams
NodeName = "TicketDesc" #Node name of netwrok graph
subunit = 'None' # Sub divided data
FileName = '.C:\\Users\\nischr\\eclipse-workspace\\eclipse-workspace-JEE\\AsDesktopNew\\src\\main\\resources\\python\\Input\\Train.xlsx'