package com.automic.dac.asdesktop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.automic.dac.asdesktop.model.TicketDetailsNgramTable;

/**
*
*
* @author Nischala 
*/
@Repository
public interface TicketDetailsNgramTableRepo extends JpaRepository<TicketDetailsNgramTable, String>{
	
	/**
	*
	*
	* get  list of TicketDetailsNgramTable object by uploadid
	*/
	List<TicketDetailsNgramTable>findByUploadid(int uploadid);

	 

}
