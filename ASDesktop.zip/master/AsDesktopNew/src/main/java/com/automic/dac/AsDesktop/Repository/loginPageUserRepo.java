package com.automic.dac.asdesktop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.automic.dac.asdesktop.model.LoginPageUser;
/**
*
*
* @author Nischala 
*/
@Repository
public interface LoginPageUserRepo extends JpaRepository<LoginPageUser, String>{
      
	
	
	/**
	*
	*
	*  to get LoginPageUser object by userid
	*/
	LoginPageUser findByUserIdAndPassword( String userId,String password);
//Boolean isLoginPageUserExistsByUserIdAndPassword( String userId,String password);
}
