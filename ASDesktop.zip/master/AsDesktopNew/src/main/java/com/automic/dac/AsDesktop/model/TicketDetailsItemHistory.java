package com.automic.dac.asdesktop.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "item_history")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TicketDetailsItemHistory {

	/**
	*
	*
	* uploadid
	*/
	private int uploadid;
	/**
	*
	*
	* inputparameter
	*/
	@Column(name ="input_parameter")
	private String inputparameter;
	/**
	*
	*
	* status
	*/
	private String status;
	/**
	*
	*
	* functiontype
	*/
	private String functiontype;	
	/**
	*
	*
	* timeofrequest
	*/
	@Id
	@Temporal(TemporalType.TIMESTAMP)
    @Column(name = "timeofrequest")
    private Date timeofrequest=new Date();
	
	/**
	*
	*
	* mlstatus
	*/
	private String mlstatus;
	
	
	
	public int getUploadid() {
		return uploadid;
	}
	/**
	*
	*
	* setUploadid
	*/
	public void setUploadid(final int uploadid) {
		this.uploadid = uploadid;
	}

	public String getInputparameter() {
		return inputparameter;
	}
	/**
	*
	*
	* setInputparameter
	*/
	public void setInputparameter(final String inputparameter) {
		this.inputparameter = inputparameter;
	}
	public String getStatus() {
		return status;
	}
	/**
	*
	*
	* setStatus
	*/
	public void setStatus(final String status) {
		this.status = status;
	}
	public String getFunctiontype() {
		return functiontype;
	}
	/**
	*
	*
	* setFunctiontype
	*/
	public void setFunctiontype(final String functiontype) {
		this.functiontype = functiontype;
	}

	
	
	public Date getTimeofrequest() {
		return timeofrequest;
	}
	/**
	*
	*
	* setTimeofrequest
	*/
	public void setTimeofrequest(final Date timeofrequest) {
		this.timeofrequest = timeofrequest;
	}
	public String getMlstatus() {
		return mlstatus;
	}
	/**
	*
	*
	* setMlstatus
	*/
	public void setMlstatus(final String mlstatus) {
		this.mlstatus = mlstatus;
	}
	/**
	*
	*
	* Constructor with fields
	*/
	public TicketDetailsItemHistory(final int uploadid,final  String inputparameter, final String status,final  String functiontype,
			final String mlstatus) {
		
		this.uploadid = uploadid;
		this.inputparameter = inputparameter;
		this.status = status;
		this.functiontype = functiontype;
		this.mlstatus = mlstatus;
	}
	/**
	*
	*
	* empty Constructor 
	*/
	public TicketDetailsItemHistory() {
	super();
	}
	
}
