import { Component, NgModule, OnInit } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { UserSetting } from '../data/user-setting';
import { Router } from '@angular/router';
import { AsDesktopService } from '../as-desktop.service';
import { ToastrService } from 'ngx-toastr';
import { LoginDetail } from '../data/login-detail';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  originalUserSetting: UserSetting = {
    clientID: '',
    userID: '',
    password: '',
    checkbox: false 
  };
  detail:LoginDetail= new LoginDetail();
  UserSetting: UserSetting = { ...this.originalUserSetting };

  constructor(private router : Router, private toastr : ToastrService,private service:AsDesktopService) { }

  ngOnInit(): void { }

  onSubmit(form: NgForm) {    
     if(form.valid){
    this.service.loginUser(this.detail)
    .subscribe({
      
      complete: () => {this.handleLoginSuccess()},
      error: () => { this.handleError()},   
      next: () => { this.handleNext() } })
      }
      
    }
  handleNext() {
    this.router.navigate(['/dashboard'])

  }
  handleError() {
    console.log("handleError")
    this.toastr.error('please enter valid user name and password')
  }
  handleLoginSuccess() {
    console.log("success")
   this.toastr.success('login successfully')
  }

  onBlur(field: NgModel) {
    console.log('in onBlur: ', field.valid);
  }



  }
