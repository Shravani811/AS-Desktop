package com.automic.dac.asdesktop.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "uploadid_master")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UploadIdMaster {
	 /**
	  *
	  *
	  *  id
	  */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	 /**
	  *
	  *
	  *  uploadId
	  */
	@Column(name = "uploadId")
	private int uploadId;
	 /**
	  *
	  *
	  *  commit
	  */
	@Column(name = "commit")
	private boolean commit;
	 /**
	  *
	  *
	  *  empty constructor
	  */
	public UploadIdMaster() {
	super();
	}
	 /**
	  *
	  *
	  *  constructor with fields
	  */
	public UploadIdMaster(final int uploadId,final  boolean commit) {
		super();

		this.uploadId = uploadId;
		this.commit = commit;
	}

	public int getId() {
		return id;
	}
	 /**
	  *
	  *
	  *  setAction_status
	  */
	public void setId(final int id) {
		this.id = id;
	}

	public int getUploadId() {
		return uploadId;
	}
	 /**
	  *
	  *
	  *  setAction_status
	  */
	public void setUploadId(final int uploadId) {
		this.uploadId = uploadId;
	}

	public boolean isCommit() {
		return commit;
	}
	 /**
	  *
	  *
	  *  setCommit
	  */
	public void setCommit(final boolean commit) {
		this.commit = commit;
	}

}
