--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

-- Started on 2022-01-13 18:41:22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 202 (class 1259 OID 48603)
-- Name: backup_uploaddata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_uploaddata (
    uploadid integer,
    filename character varying(256),
    status character varying(256),
    result character varying(256),
    iteration integer
);


ALTER TABLE public.backup_uploaddata OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 39189)
-- Name: item_history; Type: TABLE; Schema: public; Owner: asuser1
--

CREATE TABLE public.item_history (
    uploadid integer,
    input_parameter character varying(65535),
    status character varying(255),
    functiontype character varying(255),
    timeofrequest timestamp with time zone DEFAULT now(),
    mlstatus character varying(200)
);


ALTER TABLE public.item_history OWNER TO asuser1;

--
-- TOC entry 203 (class 1259 OID 48639)
-- Name: ngrambytopic; Type: TABLE; Schema: public; Owner: asuser1
--

CREATE TABLE public.ngrambytopic (
    uploadid integer,
    topic text,
    ngram text,
    count integer
);


ALTER TABLE public.ngrambytopic OWNER TO asuser1;

--
-- TOC entry 197 (class 1259 OID 39196)
-- Name: ngramtable; Type: TABLE; Schema: public; Owner: asuser1
--

CREATE TABLE public.ngramtable (
    uploadid integer,
    ngramkeyword character varying(256),
    count integer
);


ALTER TABLE public.ngramtable OWNER TO asuser1;

--
-- TOC entry 200 (class 1259 OID 48066)
-- Name: techdata; Type: TABLE; Schema: public; Owner: asuser1
--

CREATE TABLE public.techdata (
    count integer,
    technology character varying,
    uploadid integer
);


ALTER TABLE public.techdata OWNER TO asuser1;

--
-- TOC entry 201 (class 1259 OID 48339)
-- Name: techstackdata; Type: TABLE; Schema: public; Owner: asuser1
--

CREATE TABLE public.techstackdata (
    uploadid integer,
    ticket_no character varying(255),
    topic character varying,
    ticket_description character varying,
    combinedtechstacklist text,
    techstackbyticket text,
    techstackbytopic text
);


ALTER TABLE public.techstackdata OWNER TO asuser1;

--
-- TOC entry 198 (class 1259 OID 39199)
-- Name: topicdata; Type: TABLE; Schema: public; Owner: asuser1
--

CREATE TABLE public.topicdata (
    ticket_no character varying(255),
    ticket_type character varying(256),
    ticket_description character varying(65535),
    preprocessed_description character varying(65535),
    solvedworkgroup character varying(65535),
    topic character varying(65535),
    uploadid integer,
    topic_confidence_level double precision,
    action_flag character varying(1) DEFAULT 'A'::character varying,
    action_status character varying(50) DEFAULT 'Initial'::character varying,
    split_number integer DEFAULT 0
);


ALTER TABLE public.topicdata OWNER TO asuser1;

--
-- TOC entry 199 (class 1259 OID 39208)
-- Name: uploaddata; Type: TABLE; Schema: public; Owner: asuser1
--

CREATE TABLE public.uploaddata (
    uploadid integer NOT NULL,
    filename character varying(256),
    status character varying(256),
    result character varying(256),
    iteration integer DEFAULT 0
);


ALTER TABLE public.uploaddata OWNER TO asuser1;

-- Completed on 2022-01-13 18:41:23

--
-- PostgreSQL database dump complete
--

