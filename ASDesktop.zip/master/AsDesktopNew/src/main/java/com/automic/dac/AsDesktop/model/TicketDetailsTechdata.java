package com.automic.dac.asdesktop.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "techdata")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TicketDetailsTechdata {

	
	 /**
	  *
	  *
	  * uploadid
	  */
	private int uploadid;
	 /**
	  *
	  *
	  * technology
	  */
	@Id
	private String technology;
	 /**
	  *
	  *
	  * count
	  */
	private int count;
	public int getUploadid() {
		return uploadid;
	}
	 /**
	  *
	  *
	  * setUploadid
	  */
	public void setUploadid(final int uploadid) {
		this.uploadid = uploadid;
	}
	public String getTechnology() {
		return technology;
	}
	 /**
	  *
	  *
	  * setTechnology
	  */
	public void setTechnology(final String technology) {
		this.technology = technology;
	}
	public int getCount() {
		return count;
	}
	
	 /**
	  *
	  *
	  * setCount
	  */
	public void setCount(final int count) {
		this.count = count;
	}
	 /**
	  *
	  *
	  *  Constructor with fields
	  */
	public TicketDetailsTechdata(final int uploadid, final String technology,final  int count) {
		
		this.uploadid = uploadid;
		this.technology = technology;
		this.count = count;
	}
	  /**
			*
			*
			* empty Constructor
			*/
	public TicketDetailsTechdata() {
	super();
	}
	
	
	
	
	
}
