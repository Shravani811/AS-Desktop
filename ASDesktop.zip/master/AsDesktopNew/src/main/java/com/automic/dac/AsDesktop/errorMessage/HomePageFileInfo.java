package com.automic.dac.asdesktop.errormessage;
/**
*
*
* @author Nischala 
*/
public class HomePageFileInfo {
	
	/**
	*
	*
	*name 
	*/
	  private String name;
	  /**
	  *
	  *
	  * url
	  */
	  private String url;
		/**
		*
		*
		* Constructor with fields
		*/
	  public HomePageFileInfo( String name, String url) {
	    this.name = name;
	    this.url = url;
	  }
	  /**
		*
		*
		* empty Constructor
		*/
	  public HomePageFileInfo() {
			super();
		}

	public String getName() {
	    return this.name;
	  }
	  /**
	  *
	  *
	  * setName
	  */
	  public void setName(final String name) {
	    this.name = name;
	  }

	  public String getUrl() {
	    return this.url;
	  }
	  /**
	  *
	  *
	  * setUrl
	  */
	  public void setUrl(final String url) {
	    this.url = url;
	  }
	}
