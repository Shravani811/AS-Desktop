package com.automic.dac.asdesktop;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.automic.dac.asdesktop.model.LoginPageUser;
import com.automic.dac.asdesktop.repository.LoginPageUserRepo;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class LoginScreen {

	@Autowired
	LoginPageUserRepo userRepo;
	
	@Test
	@Order(1)
	public void testLogin () {
		LoginPageUser user  =  userRepo.findByUserIdAndPassword("nish","qwerty");
		System.out.println(user.getUserId());
		
		assertThat(user).isEqualTo(user);
	}

	
	
	
}
