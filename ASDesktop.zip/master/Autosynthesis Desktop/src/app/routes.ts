import { Routes } from "@angular/router";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { HomeComponent } from "./home/home.component";
import { LoginComponent } from "./login/login.component";
import { TechnologyStackComponent } from "./technology-stack/technology-stack.component";
import { TicketDetailsComponent } from "./ticket-details/ticket-details.component";
import { ViewTopKeywordComponent } from "./view-top-keyword/view-top-keyword.component";

export const appRoutes:Routes = [
    {path:'login', component: LoginComponent},
    {path: 'dashboard', component: DashboardComponent},
    {path: 'home', component: HomeComponent},
    {path: 'ticketDetails/:id', component: TicketDetailsComponent},
    {path: 'viewTopKeyWord/:id', component: ViewTopKeywordComponent},
    {path: 'viewTechnologyStack/:id', component: TechnologyStackComponent},
    {path: '', redirectTo:'login', pathMatch:'full'},
]