import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { AsDesktopService } from '../as-desktop.service';



@Component({
  selector: 'app-technology-stack',
  templateUrl: './technology-stack.component.html',
  styleUrls: ['./technology-stack.component.css']
})
export class TechnologyStackComponent implements OnInit {

  constructor(private route : ActivatedRoute,private service : AsDesktopService, private router: Router) { }
  uploadId : any;
  applicationName : string = "View Technology Stack";
  dtOptions: DataTables.Settings = {};
  dtTrigger : Subject<any> = new Subject();
  @ViewChild(DataTableDirective, {static :  false})
  dtElement !: DataTableDirective;

  //Techdata
  Techdata: any = []

  categories:any=[]
  ngOnInit(): void {    
    this.dtOptions = {
      pagingType : 'full_numbers',
      pageLength : 5,
      processing : true,
      lengthMenu : [5, 10, 25]      
    }
      this.route.params.subscribe((params: Params) => {
      this.uploadId = +params['id'];
    })
    this.gettechdata()
    this.getTopicData()

  }

  ngAfterViewInit(): void {
    this.dtTrigger.next(this.dtOptions);
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next(this.dtOptions);
    });
  }
 
    gettechdata(){

      this.service.gettechnologyStack(this.uploadId).subscribe(
          (response:Response)=>{ 
            this.Techdata = response;
            this.rerender();
          } 
        );
      }
  

    getTopicData(){
      this.service.getTopicData(this.uploadId).subscribe(
          (response:Response)=>{ 
            this.categories = response;  
            this.rerender();
          } 
        );
      }

      navigateBack(){
        this.router.navigate(['/ticketDetails/',this.uploadId])
      }

}
