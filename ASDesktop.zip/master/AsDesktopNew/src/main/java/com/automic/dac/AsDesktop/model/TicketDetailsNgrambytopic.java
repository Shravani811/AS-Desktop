package com.automic.dac.asdesktop.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "ngrambytopic")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TicketDetailsNgrambytopic {
	
	/**
	*
	*
	* uploadid
	*/
	private int uploadid;
	/**
	*
	*
	* topic
	*/
	private String topic;
	/**
	*
	*
	* ngram
	*/
	@Id
	private String ngram;
	/**
	*
	*
	*count
	*/
	private int count;
	
	public int getUploadid() {
		return uploadid;
	}
	/**
	*
	*
	* setUploadid 
	*/
	public void setUploadid(final int uploadid) {
		this.uploadid = uploadid;
	}
	
	public String getTopic() {
		return topic;
	}
	/**
	*
	*
	* setTopic 
	*/
	public void setTopic(final String topic) {
		this.topic = topic;
	}
	public String getNgram() {
		return ngram;
	}
	/**
	*
	*
	* setNgram 
	*/
	public void setNgram(final String ngram) {
		this.ngram = ngram;
	}
	public int getCount() {
		return count;
	}
	/**
	*
	*
	*  setCount 
	*/
	public void setCount(final int count) {
		this.count = count;
	}
	/**
	*
	*
	*  Constructor with fields
	*/
	public TicketDetailsNgrambytopic(final int uploadid,final String topic,final String ngram,final int count) {
		
		this.uploadid = uploadid;
		this.topic = topic;
		this.ngram = ngram;
		this.count = count;
	}
	/**
	*
	*
	* empty  Constructor  
	*/
	public TicketDetailsNgrambytopic() {
	super();
	}
	
	 
	
}
