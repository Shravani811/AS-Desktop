import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AsDesktopService } from '../as-desktop.service';
import { MergedForm } from '../data/merged-form';
import { NamedForm } from '../data/named-form';
import { SplitForm } from '../data/split-form';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  var!:any
  originalUserSetting: SplitForm = {
    groupname: '',
    splitno:''
  };
  SplitForm: SplitForm = { ...this.originalUserSetting };

  NamedFormSetting: NamedForm = {
    group: '',
    updatedGroup:''
  };
  NamedForm: NamedForm = { ...this.NamedFormSetting };

  MergedFormSetting: MergedForm = {
    mergeGroup: '',
    fromGroup:''
  };
  MergedForm: MergedForm = { ...this.MergedFormSetting };

  constructor(private toastr: ToastrService, private route: Router,private service:AsDesktopService) { }
  @Input() selectedApplication :  string = "Home";
  selectedCategory : any;
  groupName : any;
  text_list : any = [];
  @Input() category_list : any;
  @Input() uploadId : any;
  isShown: boolean = true ;
  getcommit: boolean = false ;
  static commit:boolean
  ngOnInit(): void {
 this.getcommit = this.service.getcommit();

 if(this.getcommit){
  this.isShown= false ;
 }
  
  }
  
  setApplication(applicationName: any) {
    this.selectedApplication = applicationName
    this.text_list = [];
    if(applicationName == "View Top Keyword"){
      this.route.navigate(['/viewTopKeyWord/',this.uploadId])
    }
    else if(applicationName == "View Technology Stack"){
      this.route.navigate(['/viewTechnologyStack/',this.uploadId])
    } 
    else {

      this.route.navigate(['/ticketDetails/',this.uploadId, {selectedApplication: this.selectedApplication}])
    }

  }

  disableApp(applicationName: any){
    if(this.isShown && applicationName == "View Top Keyword" && applicationName == "View Technology Stack"){

    }

  }
  nameGroupUpdate(form: NgForm){

    if(form.valid){
      this.service.upDateNameGroup(JSON.stringify(form.value),this.uploadId).subscribe({
        complete: () => {this.handleSuccess("Group Name")},
        error: () => { this.handleError()} ,
       })
       // this.toastr.success('Group Name changed successfully')

      //location.reload()
    }
  }
 
    handleError() {
      console.log("handleError")

    }
    handleSuccess(menu:any) {
     // location.reload()
     this.toastr.success(menu+' submitted successfully')

     setTimeout(()=>{                          
      this.selectedApplication = "Home";
  }, 1000);
      console.log("handleSuccess")
    }





  

  
  spliGroupSubmit(form: NgForm) {    
    if(form.valid){
      console.log(form.value)
      this.service.splitGroup(JSON.stringify(form.value),this.uploadId).subscribe({
        complete: () => {this.handleSuccess("spliGroup")},
        error: () => { this.handleError()} ,
       })
  
    }
  }

  mergeGroupSubmit(form: NgForm){
    if(form.valid){
      console.log(form.value)
      this.service.mergeGroup(JSON.stringify(form.value),this.uploadId).subscribe({
        complete: () => {this.handleSuccess("mergeGroup")},
        error: () => { this.handleError()} ,
       })

    }
  }

  
  AddWord() {
    if (window.getSelection) {
      var inputValue = window.getSelection();
      var word = String(inputValue).trim();
      if(word){
        this.text_list.push(word);
      }else{
        this.toastr.error('Please select a word')
      }
    }
  }

  removeSelectedWord(text:any){
    const index: number = this.text_list.indexOf(text);
    this.text_list.splice(index, 1);
  }
  

  SubmitWord(text_list:any){
    if(text_list.length > 0){

      this.service.removeNoise(JSON.stringify(text_list),this.uploadId).subscribe({
        complete: () => {this.handleSuccess("Remove Noise")},
        error: () => { this.handleError()} ,
       })
      console.log(text_list)


   
    }else{
      this.toastr.error('Please select a word')
    }
  }


  CommitWord(){
   
  
    this.isShown = false
    this.service.CommitWord(this.uploadId).subscribe({
      complete: () => {this.handleSuccess("CommitWord")},
      error: () => { this.handleError()} ,
     })

     this.service.Commitvalue("commit");
  }



  /*CommitWord(text_list:any){
    if(text_list.length > 0){
      this.toastr.success('Commit submitted successfully')
      console.log(text_list)
     // location.reload()
    }else{
      this.toastr.error('Please select a word')
    }
  }*/
homeButton =[
  {
    "name" : "Home"
  }
]
  applicationList = [
   

    {
      "name" : "View Top Keyword"
    },
    {
      "name" : "View Technology Stack"
    }



  ]

otherApplicationList = [

  {
    "name" : "Name Group"
  },
  {
    "name" : "Split Group"
  },
  {
    "name" : "Merge Group"
  },
  {
    "name" : "Remove Noise"
  },
  // {
  //   "name" : "Create Top Group From Selection"
  // },
  
 
]
Commit = [
  {
    "name" : "Commit"
  } 
]


  split_nos = [
    {
      key: 1, value: "1",
    },
    {
      key: 2, value: "2 ",
    },
    {
      key: 3, value: "3",
    },
   
  ]

}