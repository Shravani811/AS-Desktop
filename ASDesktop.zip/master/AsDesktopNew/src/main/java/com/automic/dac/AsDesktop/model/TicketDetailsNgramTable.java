package com.automic.dac.asdesktop.model;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "ngramtable")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TicketDetailsNgramTable {
	 /**
	  *
	  *
	  * url
	  */
	private int uploadid;
	 /**
	  *
	  *
	  * url
	  */
	@Id
	private String ngramkeyword;
	 /**
	  *
	  *
	  * url
	  */
	private int count;
	 /**
	  *
	  *
	  *  Constructor with fields
	  */
	public TicketDetailsNgramTable(final int uploadid,final  String ngramkeyword,final  int count) {
	
		this.uploadid = uploadid;
		this.ngramkeyword = ngramkeyword;
		this.count = count;
	}
	  /**
			*
			*
			* empty Constructor
			*/
	public TicketDetailsNgramTable() {
	super();
	}

	public int getUploadid() {
		return uploadid;
	}
	 /**
	  *
	  *
	  * setUploadid
	  */
	public void setUploadid(final int uploadid) {
		this.uploadid = uploadid;
	}

	public String getNgramkeyword() {
		return ngramkeyword;
	}
	 /**
	  *
	  *
	  * setNgramkeyword
	  */
	public void setNgramkeyword(final String ngramkeyword) {
		this.ngramkeyword = ngramkeyword;
	}

	public int getCount() {
		return count;
	}
	 /**
	  *
	  *
	  * setCount
	  */
	public void setCount(final int count) {
		this.count = count;
	}
	

}
