import { Component, OnInit, ViewChild } from '@angular/core';

import { ActivatedRoute, Params, Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { TokenClass } from 'typescript';
import { AsDesktopService } from '../as-desktop.service';

@Component({
  selector: 'app-ticket-details',
  templateUrl: './ticket-details.component.html',
  styleUrls: ['./ticket-details.component.css']
})
export class TicketDetailsComponent implements OnInit {

  constructor(private router : Router, private route: ActivatedRoute,private service : AsDesktopService) { }
 
 
  showHide:boolean = true;
  showPopup:boolean =  false;
  dtOptions: DataTables.Settings = {};
  col: any =[];
  uploadId: any;
  ticketList:any = [];
  arrshow : boolean = true;
  applicationName : any = "Home";
  dtTrigger : Subject<any> = new Subject();

  @ViewChild(DataTableDirective, {static : false})

  dtElement !: DataTableDirective;

  categories: any = []
  NgramValue :any = [];
  ngrambytopic:any =[]
  TechnologyStack:any =[]
  ngOnInit(): void {
    var appname = this.route.snapshot.paramMap.get('selectedApplication');
    if(appname){
      this.applicationName = appname;
    }
   

    this.col =[0,1,3,4,5];
    this.dtOptions = {
      pagingType : 'full_numbers',
      pageLength : 5,
      processing : true,
      lengthMenu : [5, 10, 25],
      "columnDefs": [
        {
            "targets": [0,1,3,4,5],
            "visible": false,
            "searchable": false
        },
        {
          "targets": [6],
          "orderable": false
        }
      ]
    }
    this.route.params.subscribe((params: Params) => {
      this.uploadId = +params['id'];
    })
  this.getTopicData()
    this.getNgramValue()
 this.gettechnologyStack()
  }

  ngAfterViewInit(): void {

    this.dtTrigger.next(this.dtOptions);

  }



  rerender(): void {

    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {

      // Destroy the table first

      dtInstance.destroy();

      // Call the dtTrigger to rerender again

      this.dtTrigger.next(this.dtOptions);

    });

  }


getNgramValue(){
  this.service.getNgramTable(this.uploadId).subscribe(
      (response:Response)=>{ 
        this.NgramValue = response;
      } 
    );
 }

 getTopicData(){

 this.service.getTopicData(this.uploadId).subscribe(
     (response:Response)=>{ 
       this.ticketList = response;
       this.categories = response;  
       this.rerender();
     } 
   );


 }

 gettechnologyStack(){

  this.service.gettechnologyStack(this.uploadId).subscribe(
      (response:Response)=>{ 
        this.TechnologyStack = response;
      } 
    );
  }
 
 
  
  


  colName : any = [
    {
      "name" : "Ticket No",
      "isDisplayed" : false,
      "colNo" : 0
    },
    {
      "name" : "Ticket type",
      "isDisplayed" : false,
      "colNo" : 1
    },
    {
      "name" : "Ticket description",
      "isDisplayed" : true,
      "colNo" : 2
    },
    {
      "name" : "Preprocessed description",
      "isDisplayed" : false,
      "colNo" : 3
    },
    {
      "name" : "Solved workgroup",
      "isDisplayed" : false,
      "colNo" : 4
    },
    {
      "name" : "Topic",
      "isDisplayed" : false,
      "colNo" : 5
    }
  ]

  
  
  showHideCol(val:any, isDisplayed:boolean){
    if(isDisplayed === true){
      this.col.push(val);
      this.colName[val].isDisplayed = false;
    }else{
      const index: number = this.col.indexOf(val);
      this.col.splice(index, 1);
      this.colName[val].isDisplayed = true;
    }

    if(this.colName.filter((item :any) => { return item.colNo !== 2 })
    .some((item : any) => item.isDisplayed === true)) {
      this.arrshow = false;
    }else if(this.colName.filter((item :any) => { return item.colNo === 2 })
    .some((item : any) => item.isDisplayed === false)) {
      this.arrshow = false;
    } else {
      this.arrshow = true;
    }
    this.getTicketList();
    //console.log(this.colName[val].isDisplayed)
  
  }


  close(){
    this.showPopup = false
  }


getTicketList(){
  $('#ticketList').DataTable().destroy();
  $('#ticketList').DataTable( {
      pagingType : 'full_numbers',
      pageLength : 5,
      processing : true,
      lengthMenu : [5, 10, 25],
      scrollX : true,
      "columnDefs": [
        {
            "targets": this.col,
            "visible": false,
            "searchable": false
        }
        
      ]
    })
}

  reset(){      



  
    this.arrshow = true;
      //console.log(this.colName)
      this.col =[0,1,3,4,5];
      this.colName.map((x:any) => { 
        if(x.colNo != 2){ x.isDisplayed = false } else{x.isDisplayed = true} });
     this.getTicketList();
  }

  editColumn(){
    this.showPopup = true
  }

  navigateBack(){
    this.router.navigate(['/home'])
  }
  
  setCategories(){
  location.reload()
}


}
