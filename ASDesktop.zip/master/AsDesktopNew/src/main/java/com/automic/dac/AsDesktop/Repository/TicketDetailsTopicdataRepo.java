package com.automic.dac.asdesktop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.automic.dac.asdesktop.model.TicketDetailsTopicdata;
/**
*
*
* @author Nischala 
*/
@Repository
public interface TicketDetailsTopicdataRepo extends JpaRepository<TicketDetailsTopicdata, String>{
	/**
	*
	*
	*  get list of TicketDetailsTopicdata object by userid
	*/
	List<TicketDetailsTopicdata>findByUploadid(int uploadid);
	/**
	*
	*
	*  get TicketDetailsTopicdata object by topic
	*/
	TicketDetailsTopicdata findByTopic(String topic);

}
