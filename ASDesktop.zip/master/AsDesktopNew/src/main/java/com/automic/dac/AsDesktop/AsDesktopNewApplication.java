package com.automic.dac.asdesktop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
*
*
* @author Nischala 
*/
@SpringBootApplication
public  class AsDesktopNewApplication {
	
	
	


/**
*
*
* when application launches,this main class will run
*/
	public static void main(final String[] args) {
		SpringApplication.run(AsDesktopNewApplication.class, args);
		
	}

}
