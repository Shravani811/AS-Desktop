export interface NamedForm{
    group:string;
    updatedGroup:string;
}