package com.automic.dac.asdesktop.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.automic.dac.asdesktop.errormessage.HomePageResponseMessage;
import com.automic.dac.asdesktop.model.HomePageFile;
import com.automic.dac.asdesktop.model.TechnologyStack;
import com.automic.dac.asdesktop.model.TicketDetailsItemHistory;
import com.automic.dac.asdesktop.model.TicketDetailsNgramTable;
import com.automic.dac.asdesktop.model.TicketDetailsNgrambytopic;
import com.automic.dac.asdesktop.model.TicketDetailsTechStackData;
import com.automic.dac.asdesktop.model.TicketDetailsTechdata;
import com.automic.dac.asdesktop.model.TicketDetailsTopicdata;
import com.automic.dac.asdesktop.model.LoginPageUser;
import com.automic.dac.asdesktop.model.UploadIdMaster;
import com.automic.dac.asdesktop.repository.LoginPageUserRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsItemHistoryRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsNgramTableRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsNgrambytopicRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsTechStackDataRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsTechdataRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsTopicdataRepo;
import com.automic.dac.asdesktop.repository.UploadIdMasterRepo;
import com.automic.dac.asdesktop.service.HomePageFileStorageService;

/**
 *
 *
 * @author Nischala
 */
@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:4200")
public class LoginPageUserController {

	/**
	 *
	 *
	 * LoginPageUserRepo
	 */
	@Autowired
	private LoginPageUserRepo userRepo;
	/**
	 *
	 *
	 * HomePageFileStorageService
	 */
	@Autowired
	private HomePageFileStorageService storageServicedb;
	/**
	 *
	 *
	 * TicketDetailsTopicdataRepo
	 */
	@Autowired
	private TicketDetailsTopicdataRepo topicdataRepo;
	/**
	 *
	 *
	 * TicketDetailsNgramTableRepo
	 */
	@Autowired
	private TicketDetailsNgramTableRepo ngramRepo;
	/**
	 *
	 *
	 * TicketDetailsNgrambytopicRepo
	 */
	@Autowired
	private TicketDetailsNgrambytopicRepo ngrambyTopicRepo;
	/**
	 *
	 *
	 * TicketDetailsTechStackDataRepo
	 */
	@Autowired
	private TicketDetailsTechStackDataRepo techStackRepo;
	/**
	 *
	 *
	 * TicketDetailsTechdataRepo
	 */
	@Autowired
	private TicketDetailsTechdataRepo techDataRepo;
	/**
	 *
	 *
	 * TicketDetailsItemHistoryRepo
	 */
	@Autowired
	private TicketDetailsItemHistoryRepo itemHistoryRepo;
	/**
	 *
	 *
	 * UploadIdMasterRepo Repository
	 */
	@Autowired
	private UploadIdMasterRepo uploadIdMasterRepo;

	/**
	 *
	 *
	 * loginUser
	 */

	/**
	 *
	 *
	 * LoginPageUserController empty constructor
	 */
	public LoginPageUserController() {
		super();
	}

	/**
	 *
	 *
	 * loginUser
	 */
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody final LoginPageUser userData) {
		try {
			final LoginPageUser loginUser = userRepo.findByUserIdAndPassword(userData.getUserId(),userData.getPassword());

			if(!loginUser.toString().isEmpty()) {
				return ResponseEntity.status(HttpStatus.OK).body(loginUser);

			}
			 else {
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("not successfull");

			}

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("not successfull");
		}
	}

	/**
	 *
	 *
	 * changePassword
	 */
	@PutMapping("/changePassword")
	public ResponseEntity<?> changePassword(@RequestBody LoginPageUser inputData) {

		try {
			LoginPageUser user = userRepo.findById(inputData.getUserId()).get();
			LoginPageUser updateUser = new LoginPageUser(inputData.getUserId(), inputData.getPassword());
			user.setPassword(inputData.getPassword());
			userRepo.save(user);
			return ResponseEntity.status(HttpStatus.OK).body(updateUser);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("not successfull");
		}
	}

	/**
	 *
	 *
	 * registerUser
	 */
	@PostMapping("/registerUser")
	public ResponseEntity<?> registerUser(@RequestBody LoginPageUser inputData) {

		try {

			final LoginPageUser newUser = new LoginPageUser(inputData.getUserId(), inputData.getPassword());

			userRepo.save(newUser);
			return ResponseEntity.status(HttpStatus.OK).body(newUser);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("not successfull");
		}
	}

	/**
	 *
	 *
	 * uploaded will store to local and file loaded db
	 */
	@PostMapping("/upload")
	public ResponseEntity<HomePageResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
		String message = "";
		try {
			storageServicedb.store(file);
			message = "Uploaded the file successfully: " + file.getOriginalFilename();
			return ResponseEntity.status(HttpStatus.OK).body(new HomePageResponseMessage(message));
		} catch (Exception e) {
			message = "Could not upload the file: " + file.getOriginalFilename() + "!";
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new HomePageResponseMessage(message));
		}
	}

	/**
	 *
	 *
	 * get list of HomePageFile value
	 */
	@SuppressWarnings("unchecked")
	@GetMapping("/fileDetail")
	public ResponseEntity<Stream<HomePageFile>> getFileDetail() {
		try {
			Stream<HomePageFile> filesDetail = storageServicedb.getFileDetail();
			return ResponseEntity.status(HttpStatus.OK).body(filesDetail);

		} catch (Exception e) {
			return (ResponseEntity<Stream<HomePageFile>>) ResponseEntity.status(HttpStatus.EXPECTATION_FAILED);
		}
	}

	/**
	 *
	 *
	 * get list of TicketDetailsTopicdata value by uploadid
	 */
	@SuppressWarnings("unchecked")
	@GetMapping("/topicdata")
	public ResponseEntity<List<TicketDetailsTopicdata>> getTopicdata(@RequestParam int uploadId) {
		try {
			return new ResponseEntity<List<TicketDetailsTopicdata>>(topicdataRepo.findByUploadid(uploadId),
					HttpStatus.OK);

		} catch (Exception e) {
			return (ResponseEntity<List<TicketDetailsTopicdata>>) ResponseEntity.status(HttpStatus.EXPECTATION_FAILED);
		}
	}

	/**
	 *
	 *
	 * get list of TicketDetailsItemHistory value by uploadid
	 */
	@GetMapping("/ItemHistory")
	public ResponseEntity<List<TicketDetailsItemHistory>> getItemHistory(@RequestParam int uploadId) {
		return new ResponseEntity<List<TicketDetailsItemHistory>>(itemHistoryRepo.findByUploadid(uploadId),
				HttpStatus.OK);
	}

	/**
	 *
	 *
	 * get list of TicketDetailsNgrambytopic value by uploadid
	 */
	@GetMapping("/ngrambytopic")
	public ResponseEntity<List<TicketDetailsNgrambytopic>> getNgrambytopic(@RequestParam int uploadId) {

		return new ResponseEntity<List<TicketDetailsNgrambytopic>>(ngrambyTopicRepo.findByUploadid(uploadId),
				HttpStatus.OK);

	}

	/**
	 *
	 *
	 * get list of TicketDetailsNgramTable value by uploadid
	 */
	@GetMapping("/ngramtable")
	public ResponseEntity<List<TicketDetailsNgramTable>> getNgramtable(@RequestParam int uploadId) {
		return new ResponseEntity<List<TicketDetailsNgramTable>>(ngramRepo.findByUploadid(uploadId), HttpStatus.OK);
	}

	/**
	 *
	 *
	 * get list of TicketDetailsTechStackData value
	 */
	@GetMapping("/techstackdata")
	public ResponseEntity<List<TicketDetailsTechStackData>> gettechstackData(@RequestParam int uploadId) {
		// Stream<TicketDetailsTechStackData> techstack =
		// techStackRepo.findAll().stream();
		return new ResponseEntity<List<TicketDetailsTechStackData>>(techStackRepo.findByUploadid(uploadId),
				HttpStatus.OK);
	}

	/**
	 *
	 *
	 * get list of technology stack value from by techstack table
	 */
	@GetMapping("/technologyStack")
	public ResponseEntity<List<TechnologyStack>> gettechnologyStack(@RequestParam int uploadId) {
		final List<TicketDetailsTechStackData> techStackData = techStackRepo.findByUploadid(uploadId);
		List<TechnologyStack> technologydata = new ArrayList<>();

		final List<TechnologyStack> resultData = new ArrayList<>();

		try {

			for (final TicketDetailsTechStackData stackData : techStackData) {
				String technologyStack = stackData.getTechstackbytopic();

				int k = 0;
				final String substr = technologyStack.substring(1, technologyStack.length() - 1);

				final String strReplace = substr.replace("],", "];");

				String[] tokens = strReplace.split(";");

				for (final String nd : tokens) {
					final String[] tokens2 = nd.split(":");

					if (k <= 5 && tokens2.length > 1) {

						final String cntval = tokens2[1].replace("[", "").split(",")[0];

						final float cnt = Float.valueOf(cntval);

						final String conf = tokens2[1].replace("]", "").split(",")[1].trim();

						final float confidence = Float.valueOf(conf) * 100;

						technologydata.add(new TechnologyStack(tokens2[0], Math.round(cnt), confidence));
						resultData.add(new TechnologyStack(tokens2[0], Math.round(cnt), confidence));
						k++;
					}

				}
			}

		}

		catch (final NumberFormatException e) {
			System.out.println(e.getMessage());
		}

		for (int i = 0; i < technologydata.size(); i++) {
			for (int j = 0; j < resultData.size(); j++) {

				if (technologydata.get(i).getTechnology().trim().equals(resultData.get(j).getTechnology().trim())
						&& technologydata.get(i).getConfidence().equals(resultData.get(j).getConfidence()) && i != j) {

					final int sum = technologydata.get(i).getCount() + resultData.get(j).getCount();
					technologydata.get(i).setCount(sum);
					resultData.remove(j);
					technologydata.remove(j);
					j--;
				}
			}

		}

		return new ResponseEntity<List<TechnologyStack>>(technologydata, HttpStatus.OK);

	}

	/**
	 *
	 *
	 * get list of TicketDetailsTechdata by uploadid
	 */
	@GetMapping("/techdata")
	public ResponseEntity<List<TicketDetailsTechdata>> getTechData(@RequestParam int uploadId) {
		return new ResponseEntity<List<TicketDetailsTechdata>>(techDataRepo.findByUploadid(uploadId), HttpStatus.OK);
	}

	/**
	 *
	 *
	 * upDateNameGroup update value to db
	 */
	@PutMapping(value = "/upDateNameGroup")
	public ResponseEntity<HomePageResponseMessage> upDateNameGroup(@RequestParam int uploadId,
			@RequestParam String form) {
		String message = "";

		try {
			// update in topic data
			final JSONObject obj = new JSONObject(form);
			TicketDetailsTopicdata topicdata = topicdataRepo.findByTopic(obj.get("group").toString());
			topicdata.setTopic(obj.get("updatedGroup").toString());
			topicdataRepo.save(topicdata);

			// insert into item history
			String str = obj.get("group").toString() + " -> " + obj.get("updatedGroup").toString();

			final TicketDetailsItemHistory itemHistory = new TicketDetailsItemHistory(uploadId, str, "completed",
					"NameGroup", "");
			itemHistoryRepo.save(itemHistory);

			message = "upDated the NameGroup successfully: " + form;

			return ResponseEntity.status(HttpStatus.OK).body(new HomePageResponseMessage(message));

		} catch (Exception e) {
			message = "Could not updated the NameGroup: " + form + "!";

			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new HomePageResponseMessage(message));
		}
	}

	/**
	 *
	 *
	 * splitGroup insert value to db
	 */
	@PutMapping(value = "/splitGroup")
	public ResponseEntity<HomePageResponseMessage> splitGroup(@RequestParam int uploadId, @RequestParam String form) {
		String message = "";
		try {

			JSONObject obj = new JSONObject(form);
			long count = itemHistoryRepo.countByuploadidAndStatusAndFunctiontype(uploadId, "pending", "SplitGroup");
			List<TicketDetailsItemHistory> Inputparameter = itemHistoryRepo
					.findByInputparameterContaining(obj.get("groupname").toString());
			long count1 = Inputparameter.size();

			if (count == 0 && count1 == 0) {

				// update topicData value only if input parameter not contain in item list
				TicketDetailsTopicdata topicdata = topicdataRepo.findByTopic(obj.get("groupname").toString());
				topicdata.setsplitNumber(uploadId);
				topicdata.setactionFlag("M");
				topicdata.setactionStatus("pending");
				topicdataRepo.save(topicdata);
				// insert into item history
				final String str = obj.get("groupname").toString();
				TicketDetailsItemHistory itemHistory = new TicketDetailsItemHistory(uploadId, str, "pending",
						"SplitGroup", "");
				itemHistoryRepo.save(itemHistory);
				message = "Uploaded the splitGroup successfully: " + form;
			} else {
				message = "splitGroup already updated in item history: " + form;
			}
			return ResponseEntity.status(HttpStatus.OK).body(new HomePageResponseMessage(message));
		} catch (Exception e) {
			message = "Could not upload the splitGroup: " + form + "!";
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new HomePageResponseMessage(message));
		}
	}

	/**
	 *
	 *
	 * mergeGroup insert value to db
	 */
	@PutMapping(value = "/mergeGroup")
	public ResponseEntity<HomePageResponseMessage> mergeGroup(@RequestParam int uploadId, @RequestParam String form) {
		String message = "";
		try {

			JSONObject obj = new JSONObject(form);

			// update topicData value
			TicketDetailsTopicdata fromGroup = topicdataRepo.findByTopic(obj.get("fromGroup").toString());

			// TicketDetailsTopicdata mergeGroup =
			// topicdataRepo.findByTopic(obj.get("mergeGroup").toString());
			fromGroup.setTopic(obj.get("mergeGroup").toString());

			fromGroup.setactionFlag("M");
			fromGroup.setactionStatus("Pending");
			topicdataRepo.save(fromGroup);

			// insert into item history
			String str = obj.get("fromGroup").toString() + " -> " + obj.get("mergeGroup").toString();
			TicketDetailsItemHistory itemHistory = new TicketDetailsItemHistory(uploadId, str, "completed",
					"mergeGroup", "Pending");
			itemHistoryRepo.save(itemHistory);

			message = "Uploaded the mergeGroup successfully: " + form;

			return ResponseEntity.status(HttpStatus.OK).body(new HomePageResponseMessage(message));
		} catch (Exception e) {
			message = "Could not upload the mergeGroup: " + form + "!";

			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new HomePageResponseMessage(message));
		}
	}

	/**
	 *
	 *
	 * removeNoise insert value to db
	 */
	@PutMapping(value = "/removenoise")
	public ResponseEntity<HomePageResponseMessage> removeNoise(@RequestParam int uploadId,
			@RequestParam String removeText) {
		String message = "";
		try {
			final JSONArray obj = new JSONArray(removeText);
			String[] removeNoise = new String[obj.length()];

			for (int i = 0; i < obj.length(); i++) {
				removeNoise[i] = obj.getString(i).toString();

			}
			// insert into item history
			final TicketDetailsItemHistory itemHistory = new TicketDetailsItemHistory(uploadId,
					String.join(",", removeNoise), "completed", "removenoise", "Pending");
			itemHistoryRepo.save(itemHistory);

			message = "Uploaded the removenoise successfully: " + removeText;

			return ResponseEntity.status(HttpStatus.OK).body(new HomePageResponseMessage(message));
		} catch (Exception e) {
			message = "Could not upload the removenoise: " + removeText + "!";

			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new HomePageResponseMessage(message));
		}
	}

	/**
	 *
	 *
	 * CommitWord insert value to db
	 */
	@PutMapping(value = "/CommitWord")
	public ResponseEntity<HomePageResponseMessage> CommitWord(@RequestParam int uploadId) {

		String message = "";
		try {

			// insert into uploadIdMaster
			UploadIdMaster commitWord = new UploadIdMaster(uploadId, true);
			uploadIdMasterRepo.save(commitWord);
			message = "Uploaded the Commit successfully ";

			return ResponseEntity.status(HttpStatus.OK).body(new HomePageResponseMessage(message));
		} catch (Exception e) {
			message = "Could not update the Commit !";

			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new HomePageResponseMessage(message));
		}
	}

}
