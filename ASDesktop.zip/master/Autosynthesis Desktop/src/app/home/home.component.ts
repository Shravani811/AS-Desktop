import { HttpEventType, HttpRequest, HttpResponse } from '@angular/common/http';
import { Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, Subscription } from 'rxjs';
import { AsDesktopService } from '../as-desktop.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy  {

  constructor(private router: Router, private toastr : ToastrService,private service:AsDesktopService) { }

  fileToUpload: File | null = null;
  uploadedFilename!: string;
  formData!: FormData;
  isFileReady!: boolean;
  fileErrorMessage!: boolean;
 dtOptions: DataTables.Settings = {};
  dtTrigger : Subject<any> = new Subject();
  
 selectedFiles?: FileList;
  currentFile?: File;
  fileInfos?: Observable<any>;
  previousFileName:String=''

  message = '';
  UploadId:string='1'
  fileDetail!: any;
  sub!:Subscription
 
@ViewChild(DataTableDirective, {static : false})		
dtElement !: DataTableDirective;

  ngOnInit(): void {
     this.dtOptions = {
     pagingType : 'full_numbers',
      pageLength : 5,
      processing : true,
      lengthMenu : [5, 10, 25]
     }
   this.getFiles();
  }

  ngAfterViewInit(): void {	
    this.dtTrigger.next(this.dtOptions);
    }
    
    getFiles(){
  
      this.sub = this.service.getFileDetail().subscribe(
      (response:Response)=>{ 
       setTimeout(() => {
        this.fileDetail = response; 
        this.rerender(); 
       });
    
      } 
    );
   }
 
   rerender(): void {
     this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
       // Destroy the table first
       dtInstance.destroy();
       // Call the dtTrigger to rerender again
       this.dtTrigger.next(this.dtOptions);
     });
}


  handleFileInput(event:any) {
    const files : FileList = event.target.files
   this.selectedFiles = event.target.files;
   

if (files.length === 0) {
      this.isFileReady = false;
      this.uploadedFilename = '';
      this.toastr.error('Please select file')
    }else{
      this.uploadedFilename = files[0].name;
      const fileExtension = this.uploadedFilename.substr(
        this.uploadedFilename.lastIndexOf('.') + 1,
        this.uploadedFilename.lastIndexOf('.')
      );
      let fileSize = (files[0].size / 1024) / 1024;

      if (fileExtension === 'xls' || fileExtension === 'xlsx') {
        this.fileErrorMessage = false;
        this.isFileReady = true;
        this.formData = new FormData();
        this.formData.append('file', files[0], files[0].name);
        // console.log(files);
        // console.log(this.formData);
      } else {
        this.fileErrorMessage = true;
        this.uploadedFilename = '';
        this.toastr.error('Invalid file format')
      }
    }
}

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe()
  }



uploadFile(event: any) {
 
 

  if (this.selectedFiles) {
    const file: File | null = this.selectedFiles.item(0);
    if (file) {
    this.currentFile = file;
   

    this.service.upload(this.currentFile)
    .subscribe({
      complete: () => {this.handleSuccess()},
      error: () => { this.handleError()}, 
      next: () => { this.handleNext() } })
      }
      
    }
  }
  handleNext() {
  //location.reload();
   
   
   
  }
  handleError() {
    this.toastr.success('please upload valid file')
  }
  handleSuccess() {
    this.service.getFileDetail().subscribe(	
      (response:Response)=>{		
      this.fileDetail = response;		
      this.rerender();		
      }		
      );
    }

  ticketDetails(upload_id:any){	
    this.router.navigate(['/ticketDetails/',upload_id])	
    }


  navigateBack(){
    this.router.navigate(['/dashboard'])
  }

  reset(){
    this.uploadedFilename = '';
  }

  
}
