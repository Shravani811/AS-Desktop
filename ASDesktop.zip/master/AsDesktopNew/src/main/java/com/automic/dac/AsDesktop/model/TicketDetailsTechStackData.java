package com.automic.dac.asdesktop.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "techstackdata")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TicketDetailsTechStackData {

	

	 /**
	  *
	  *
	  * uploadid
	  */
	private int uploadid;
	 /**
	  *
	  *
	  * ticket_no
	  */
	private String ticketNo;
	
	 /**
	  *
	  *
	  * topic
	  */
	@Id
	private String topic;
	 /**
	  *
	  *
	  * ticket_description
	  */
	private String ticketDescription;
	 /**
	  *
	  *
	  * combinedtechstacklist
	  */
	private String combinedtechstacklist;
	 /**
	  *
	  *
	  * techstackbyticket
	  */
	private String techstackbyticket;
	 /**
	  *
	  *
	  * techstackbytopic
	  */
	private String techstackbytopic;
	
	public int getUploadid() {
		return uploadid;
	}
	 /**
	  *
	  *
	  * setUploadid
	  */
	public void setUploadid(final int uploadid) {
		this.uploadid = uploadid;
	}
	public String getticketNo() {
		return ticketNo;
	}
	 /**
	  *
	  *
	  * setticketNo
	  */
	public void setticketNo(final String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getTopic() {
		return topic;
	}
	 /**
	  *
	  *
	  * setTopic
	  */
	public void setTopic(final String topic) {
		this.topic = topic;
	}
	public String getticketDescription() {
		return ticketDescription;
	}
	 /**
	  *
	  *
	  * setticketDescription
	  */
	public void setticketDescription(final String ticketDescription) {
		this.ticketDescription = ticketDescription;
	}
	public String getCombinedtechstacklist() {
		return combinedtechstacklist;
	}
	 /**
	  *
	  *
	  * setCombinedtechstacklist
	  */
	public void setCombinedtechstacklist(final String combinedtechstacklist) {
		this.combinedtechstacklist = combinedtechstacklist;
	}
	public String getTechstackbyticket() {
		return techstackbyticket;
	}
	 /**
	  *
	  *
	  * setTechstackbyticket
	  */
	public void setTechstackbyticket(final String techstackbyticket) {
		this.techstackbyticket = techstackbyticket;
	}
	public String getTechstackbytopic() {
		return techstackbytopic;
	}
	 /**
	  *
	  *
	  * setTechstackbytopic
	  */
	public void setTechstackbytopic(final String techstackbytopic) {
		this.techstackbytopic = techstackbytopic;
	}
	 /**
	  *
	  *
	  * Constructor with fields
	  */
	public TicketDetailsTechStackData(final int uploadid,final  String ticketNo,final  String topic,final  String ticketDescription,
			final String combinedtechstacklist,final  String techstackbyticket,final  String techstackbytopic) {
		super();	this.uploadid = uploadid;
		this.ticketNo = ticketNo;
		this.topic = topic;
		this.ticketDescription = ticketDescription;
		this.combinedtechstacklist = combinedtechstacklist;
		this.techstackbyticket = techstackbyticket;
		this.techstackbytopic = techstackbytopic;
	}
	 /**
	  *
	  *
	  * empty Constructor
	  */
	public TicketDetailsTechStackData() {
		super();
	}
	
	
}