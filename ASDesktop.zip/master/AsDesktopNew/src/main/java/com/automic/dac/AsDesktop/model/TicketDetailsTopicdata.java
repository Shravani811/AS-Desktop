package com.automic.dac.asdesktop.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "topicdata")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TicketDetailsTopicdata {
	 /**
	  *
	  *
	  *  ticket_no
	  */
	@Id
	private String ticketNo;
	 /**
	  *
	  *
	  *  ticket_type
	  */
	private String ticketType;
	 /**
	  *
	  *
	  *  ticket_description
	  */
	private String ticketDescription;
	 /**
	  *
	  *
	  *  preprocessed_description
	  */
	private String preprocessedDescription;
	 /**
	  *
	  *
	  *  solvedworkgroup
	  */
	private String solvedworkgroup;
	 /**
	  *
	  *
	  *  topic
	  */
	private String topic;
	
	 /**
	  *
	  *
	  * uploadid
	  */
	private int uploadid;
	 /**
	  *
	  *
	  *  topic_confidence_level
	  */
	private double topicConfidenceLevel;
	 /**
	  *
	  *
	  *  action_flag
	  */
	private String actionFlag;
	 /**
	  *
	  *
	  * actionStatus
	  */
	private String actionStatus;
	 /**
	  *
	  *
	  *  split_number
	  */
	private int splitNumber;
	
	
	
	 /**
	  *
	  *
	  *  Constructor with fields
	  */
	public TicketDetailsTopicdata(final String ticketNo,final  String ticketType, final String ticketDescription,
			final String preprocessedDescription,final  String solvedworkgroup,final  String topic,final  int uploadid,
			final double topicConfidenceLevel, final String actionFlag, final String actionStatus,final  int splitNumber) {
		
		this.ticketNo = ticketNo;
		this.ticketType = ticketType;
		this.ticketDescription = ticketDescription;
		this.preprocessedDescription = preprocessedDescription;
		this.solvedworkgroup = solvedworkgroup;
		this.topic = topic;
		this.uploadid = uploadid;
		this.topicConfidenceLevel = topicConfidenceLevel;
		this.actionFlag = actionFlag;
		this.actionStatus = actionStatus;
		this.splitNumber = splitNumber;
	}
	 /**
	  *
	  *
	  *  empty Constructor 
	  */
	public TicketDetailsTopicdata() {
	super();
	}
	public String getticketNo() {
		return ticketNo;
	}
	 /**
	  *
	  *
	  * setticketNo
	  */
	public void setticketNo(final String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getticketType() {
		return ticketType;
	}
	 /**
	  *
	  *
	  *setticketType
	  */
	public void setticketType(final String ticketType) {
		this.ticketType = ticketType;
	}
	public String getticketDescription() {
		return ticketDescription;
	}
	 /**
	  *
	  *
	  * setticketDescription
	  */
	public void setticketDescription(final String ticketDescription) {
		this.ticketDescription = ticketDescription;
	}
	public String getpreprocessedDescription() {
		return preprocessedDescription;
	}
	 /**
	  *
	  *
	  *  setpreprocessedDescription
	  */
	public void setpreprocessedDescription(final String preprocessedDescription) {
		this.preprocessedDescription = preprocessedDescription;
	}
	public String getSolvedworkgroup() {
		return solvedworkgroup;
	}
	 /**
	  *
	  *
	  *setSolvedworkgroup
	  */
	public void setSolvedworkgroup(final String solvedworkgroup) {
		this.solvedworkgroup = solvedworkgroup;
	}
	public String getTopic() {
		return topic;
	}
	 /**
	  *
	  *
	  * setTopic
	  */
	public void setTopic(final String topic) {
		this.topic = topic;
	}
	public int getUploadid() {
		return uploadid;
	}
	 /**
	  *
	  *
	  * setUploadid
	  */
	public void setUploadid(final int uploadid) {
		this.uploadid = uploadid;
	}
	public double gettopicConfidenceLevel() {
		return topicConfidenceLevel;
	}
	 /**
	  *
	  *
	  * settopicConfidenceLevel
	  */
	public void settopicConfidenceLevel(final double topicConfidenceLevel) {
		this.topicConfidenceLevel = topicConfidenceLevel;
	}
	public String getactionFlag() {
		return actionFlag;
	}
	 /**
	  *
	  *
	  *setactionFlag
	  */
	public void setactionFlag(final String actionFlag) {
		this.actionFlag = actionFlag;
	}
	public String getactionStatus() {
		return actionStatus;
	}
	 /**
	  *
	  *
	  *  setactionStatus
	  */
	public void setactionStatus(final String actionStatus) {
		this.actionStatus = actionStatus;
	}
	public int getsplitNumber() {
		return splitNumber;
	}
	 /**
	  *
	  *
	  * setsplitNumber
	  */
	public void setsplitNumber(final int splitNumber) {
		this.splitNumber = splitNumber;
	}
	
	
}
