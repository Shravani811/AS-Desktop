package com.automic.dac.asdesktop;



import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.containsStringIgnoringCase;

import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.automic.dac.asdesktop.controller.LoginPageUserController;
import com.automic.dac.asdesktop.errormessage.HomePageResponseMessage;
import com.automic.dac.asdesktop.model.TechnologyStack;
import com.automic.dac.asdesktop.model.TicketDetailsItemHistory;
import com.automic.dac.asdesktop.model.TicketDetailsTopicdata;
import com.automic.dac.asdesktop.repository.TicketDetailsItemHistoryRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsTopicdataRepo;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class MenuTest {

	
	@Autowired
	LoginPageUserController controller;
	
	@Autowired
	TicketDetailsTopicdataRepo topicdataRepo;
	
	
	
	@Autowired
	TicketDetailsItemHistoryRepo itemHistoryRepo;
	
	
	@Test
	@Order(1)
	public void testupdateNameGroup() {
		TicketDetailsTopicdata topicdata = topicdataRepo.findByTopic("model__revision__translate__precise");
		topicdata.setTopic("revision__translate__precise");
		topicdataRepo.save(topicdata);
		TicketDetailsItemHistory itemHistory = new TicketDetailsItemHistory(45, "model__revision__translate__precise->revision__translate__precise", "completed",
				"NameGroup", "");
		itemHistoryRepo.save(itemHistory);
		assertThat(topicdata.getUploadid()).isEqualTo(45);
		

	}
	
	@Test
	@Order(2)
	public void testSplitGroup() {
		ResponseEntity<HomePageResponseMessage> technologyStack=controller.splitGroup(45,"form");
		assertThat(technologyStack.getBody().getMessage()).containsIgnoringCase("Could not upload the splitGroup");		
	
	}
	@Test
	@Order(3)
	public void testMergeGroup() {
		TicketDetailsTopicdata topicdata = topicdataRepo.findByTopic("model__revision__translate__precise");
		assertThat(topicdata.getUploadid()).isEqualTo(45);

	}
	@Test
	@Order(4)
	public void testRemoveNoise() {
		TicketDetailsTopicdata topicdata = topicdataRepo.findByTopic("model__revision__translate__precise");
		assertThat(topicdata.getUploadid()).isEqualTo(45);

	}
	@Test
	@Order(5)
	public void ViewTopKeywords() {
		TicketDetailsTopicdata topicdata = topicdataRepo.findByTopic("model__revision__translate__precise");
		assertThat(topicdata.getUploadid()).isEqualTo(45);

	}
	@Test
	@Order(6)
	public void ViewTechnologyStack() {
		TicketDetailsTopicdata topicdata = topicdataRepo.findByTopic("model__revision__translate__precise");
		assertThat(topicdata.getUploadid()).isEqualTo(45);

	}
	
	
	@Test
	@Order(7)
	public void Commit() {
		TicketDetailsTopicdata topicdata = topicdataRepo.findByTopic("model__revision__translate__precise");
		assertThat(topicdata.getUploadid()).isEqualTo(45);

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
