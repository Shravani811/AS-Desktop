package com.automic.dac.asdesktop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.automic.dac.asdesktop.model.TicketDetailsItemHistory;
/**
*
*
* @author Nischala 
*/
@Repository
public interface TicketDetailsItemHistoryRepo extends JpaRepository<TicketDetailsItemHistory, String> {
	/**
	*
	*
	* get list of TicketDetailsItemHistory object by userid
	*/
	List<TicketDetailsItemHistory> findByUploadid(int uploadid);
	/**
	*
	*
	* get count of list from uploadid,status and functiontype
	*/	
	
	long countByuploadidAndStatusAndFunctiontype(int uploadid,String status,String functiontype);
	/**
	*
	*
	* get list of TicketDetailsItemHistory object by inputparameter
	*/
	List<TicketDetailsItemHistory> findByInputparameterContaining(String inputparameter);

	
	

	 

}
