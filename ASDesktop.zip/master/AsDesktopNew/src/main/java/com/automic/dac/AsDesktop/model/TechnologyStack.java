package com.automic.dac.asdesktop.model;



/**
*
*
* @author Nischala 
*/
public class TechnologyStack {
	/**
	*
	*
	* technology
	*/
	private String technology;
	/**
	*
	*
	* count
	*/
	private int count;
	/**
	*
	*
	* confidence
	*/
	private Float confidence;
	
	public String getTechnology() {
		return technology;
	}
	
	/**
	*
	*
	* setTechnology
	*/
	public void setTechnology(final String technology) {
		this.technology = technology;
	}
	public int getCount() {
		return count;
	}
	/**
	*
	*
	* setCount
	*/
	public void setCount(final int count) {
		this.count = count;
	}
	public Float getConfidence() {
		return confidence;
	}
	/**
	*
	*
	* setConfidence
	*/
	public void setConfidence(final Float confidence) {
		this.confidence = confidence;
	}
	/**
	*
	*
	* Constructor with fields
	*/
	public TechnologyStack(final String technology, final int count, final Float confidence) {
	
		this.technology = technology;
		this.count = count;
		this.confidence = confidence;
	}
	/**
	*
	*
	* empty Constructor 
	*/
	public TechnologyStack() {
		super();
	}	
	
	
}
