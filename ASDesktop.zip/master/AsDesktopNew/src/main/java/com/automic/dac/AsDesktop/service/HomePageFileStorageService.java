package com.automic.dac.asdesktop.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.automic.dac.asdesktop.model.HomePageFile;
import com.automic.dac.asdesktop.repository.HomePageFileRepo;



/**
*
*
* @author Nischala 
*/
@Service
public class HomePageFileStorageService {
	/**
	  *
	  *
	  * HomePageFile Repository 
	  */
	@Autowired
	private HomePageFileRepo fileRepository;
	/**
	  *
	  *
	  * path 
	  */
	private String path = "/Download/AsDesktopuploadedFiles//";
	 //int count =10;
	
	
	/**
	  *
	  *
	  * empty Constructor 
	  */
	public HomePageFileStorageService() {
	super();	
	}
	/**
	  *
	  *
	  * create the folder if not exist 
	  */
	public void  init() {
		final File theDir = new File("/Download/AsDesktopuploadedFiles");
		if (!theDir.exists()){
		    theDir.mkdirs();
		}
		
	}

	
	/**
	  *
	  *
	  * store uploaded file in local and load file name in db
	  */
	public HomePageFile store(final MultipartFile file) throws IOException {
		
		init();
		final String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		
		
		final Path targetLocation = Paths.get(path+fileName);
         Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

		
		final HomePageFile fileDB = new HomePageFile( "completed",fileName, "completed",1);

		return fileRepository.save(fileDB);
	}
	/**
	  *
	  *
	  * getFile from  db
	  */
	public HomePageFile getFile(final String id) {
		
		return fileRepository.findById(id).get();
	}
	/**
	  *
	  *
	  * getAllFiles from  db
	  */
	public Stream<HomePageFile> getAllFiles() {
		return fileRepository.findAll().stream();
	}
	/**
	  *
	  *
	  * getFileDetail from  db
	  */
	public Stream<HomePageFile>  getFileDetail() {
		return  fileRepository.findAll().stream();
	}
	
	
	
}