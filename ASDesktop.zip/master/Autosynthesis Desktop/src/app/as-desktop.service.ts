import { HttpClient, HttpEvent, HttpParams, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { catchError, map, Observable, pipe, throwError } from 'rxjs';
import { LoginDetail } from './data/login-detail';
import { UserSetting } from './data/user-setting';

@Injectable({
  providedIn: 'root'
})
export class AsDesktopService {
  private url = 'http://localhost:8081/user';
  uploadId!:number ;
  
  constructor(private httpClient:HttpClient) { }
 
loginUser(detail:LoginDetail):Observable<object>{

  var name=detail.userId;
 sessionStorage.setItem("username",JSON.stringify(name));

  return this.httpClient.post(`${this.url}/login`, detail);

}
getUserID(){
  
 var username = sessionStorage.getItem("username");
if(username)
return JSON.parse(username)
   
}



upload(file: File): Observable<HttpEvent<any>> {
  const formData: FormData = new FormData();
  formData.append('file', file);
  const req = new HttpRequest('POST', `${this.url}/upload`, formData, {
    reportProgress: true,
    responseType: 'json'
  });

  return this.httpClient.request(req);
  }

 getFileDetail():Observable<any> {
  return this.httpClient.get(`${this.url}/fileDetail`);
  }


getTopicData(id: any):Observable<any>{
  let params = new HttpParams().set("uploadId",id)
  return this.httpClient.get(`${this.url}/topicdata`,{params: params });
}

getNgramTable(id: any):Observable<any>{
  let params = new HttpParams().set("uploadId",id)
  return this.httpClient.get(`${this.url}/ngramtable`,{params: params });
}


getTechdata(id: any):Observable<any>{
let params = new HttpParams().set("uploadId",id)
  return this.httpClient.get(`${this.url}/techdata`, {params: params });
}
gettechstackData(id: any):Observable<any>{
  let params = new HttpParams().set("uploadId",id)
    return this.httpClient.get(`${this.url}/techstackdata`, {params: params });
    
  }

  gettechnologyStack(id: any):Observable<any>{
    let params = new HttpParams().set("uploadId",id)
      return this.httpClient.get(`${this.url}/technologyStack`, {params: params });
    }









getngrambytopic(id: any):Observable<any>{
  let params = new HttpParams().set("uploadId",id)
  return this.httpClient.get(`${this.url}/ngrambytopic`,{params: params });
}



upDateNameGroup(form: any,id: any): Observable<HttpEvent<any>> {

  const formData: FormData = new FormData();
  formData.append('form', form);
  let params = new HttpParams().set("uploadId",id)
  const req = new HttpRequest('PUT', `${this.url}/upDateNameGroup`,formData,{params: params });
  return this.httpClient.request(req);
  }

  splitGroup(form: any,id: any): Observable<HttpEvent<any>> {
   
    const formData: FormData = new FormData();
    formData.append('form', form);
    let params = new HttpParams().set("uploadId",id)

    const req = new HttpRequest('PUT', `${this.url}/splitGroup`, formData, {params: params });
  
    return this.httpClient.request(req);
    }
    mergeGroup(form: any,id: any): Observable<HttpEvent<any>> {
    
      const formData: FormData = new FormData();
      formData.append('form', form);
      let params = new HttpParams().set("uploadId",id)
      const req = new HttpRequest('PUT', `${this.url}/mergeGroup`, formData, {params: params });
    
      return this.httpClient.request(req);
      }

      removeNoise(removeText: any,id: any): Observable<HttpEvent<any>> {
        const formData: FormData = new FormData();
        formData.append('removeText', removeText);
        let params = new HttpParams().set("uploadId",id)
        const req = new HttpRequest('PUT', `${this.url}/removenoise`, formData, {params: params });
        return this.httpClient.request(req);
        }

       
        CommitWord(id: any): Observable<HttpEvent<any>> {
          let params = new HttpParams().set("uploadId",id)
          const req = new HttpRequest('PUT', `${this.url}/CommitWord?uploadId=`+id,{params: params });
          return this.httpClient.request(req);
          }
          Commitvalue(commit:any){
            sessionStorage.setItem('commit', 'commit'); 
          }    
          getcommit(): boolean{
           if(sessionStorage.getItem('commit') == 'commit'){
            return true;
           }else{
            return false;
           }

          }

}
