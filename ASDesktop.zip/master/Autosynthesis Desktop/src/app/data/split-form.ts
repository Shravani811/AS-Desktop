export interface SplitForm{
    groupname:string;
    splitno:string;
}