export class LoginDetail {
    userId!:String;
    password!:String; 
}
