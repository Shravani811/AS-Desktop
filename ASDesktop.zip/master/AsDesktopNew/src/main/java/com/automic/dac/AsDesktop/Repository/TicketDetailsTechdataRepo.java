package com.automic.dac.asdesktop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.automic.dac.asdesktop.model.TicketDetailsTechdata;
/**
*
*
* @author Nischala 
*/
	@Repository
	public interface TicketDetailsTechdataRepo extends JpaRepository<TicketDetailsTechdata, String>{
		/**
		*
		*
		* get list of TicketDetailsTechdata object by userid
		*/
		List<TicketDetailsTechdata>findByUploadid(int uploadid);
	}