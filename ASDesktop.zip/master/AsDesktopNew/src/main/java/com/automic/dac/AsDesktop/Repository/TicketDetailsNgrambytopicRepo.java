package com.automic.dac.asdesktop.repository;

import java.util.List;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.automic.dac.asdesktop.model.TicketDetailsNgrambytopic;




/**
*
*
* @author Nischala 
*/
@Repository
public interface TicketDetailsNgrambytopicRepo  extends JpaRepository<TicketDetailsNgrambytopic, String>{
	/**
	*
	*
	* get list of TicketDetailsNgrambytopic object by userid
	*/
	List<TicketDetailsNgrambytopic>findByUploadid(int uploadid);
	/**
	*
	*
	* get  TicketDetailsNgrambytopic object by topic
	*/
	TicketDetailsNgrambytopic findByTopic(String topic);

}
