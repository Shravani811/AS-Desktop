package com.automic.dac.asdesktop.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.automic.dac.asdesktop.model.HomePageFile;


/**
*
*
* @author Nischala 
*/
@Repository
public interface HomePageFileRepo extends JpaRepository<HomePageFile, String> {
  


}
