import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { AsDesktopService } from '../as-desktop.service';

@Component({
  selector: 'app-view-top-keyword',
  templateUrl: './view-top-keyword.component.html',
  styleUrls: ['./view-top-keyword.component.css']
})
export class ViewTopKeywordComponent implements OnInit {

  constructor(private route : ActivatedRoute,private service: AsDesktopService, private router: Router) { }
  uploadId : any;
  applicationName : string = "View Top Keyword";
  dtOptions: DataTables.Settings = {};
  dtTrigger : Subject<any> = new Subject();
  @ViewChild(DataTableDirective, {static : false})
  dtElement !: DataTableDirective;
  submitbtn :any;
  //NgramValue
  NgramValue:any=[]
 categories:any = []
  ngOnInit(): void {
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      lengthMenu : [5, 10, 25],
      order:[[1,"desc"]]
    }
    this.route.params.subscribe((params: Params) => {
      this.uploadId = +params['id'];
    })
   this.getTopKey()
   this. getTopicData()
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next(this.dtOptions);
    }
    
    
    rerender(): void {
      this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
        // Destroy the table first
        dtInstance.destroy();
        // Call the dtTrigger to rerender again
        this.dtTrigger.next(this.dtOptions);
      });
    }

  getTopKey(){
    this.service.getNgramTable(this.uploadId).subscribe(
      (response:Response)=>{ 
        this.NgramValue = response;
      	this.rerender()
      } 
    );
 }
 getTopicData(){

  this.service.getTopicData(this.uploadId).subscribe(
      (response:Response)=>{ 
        this.categories = response;  
        this.rerender();
      } 
    );
  }

  navigateBack(){
    this.router.navigate(['/ticketDetails/',this.uploadId])
  }



}
