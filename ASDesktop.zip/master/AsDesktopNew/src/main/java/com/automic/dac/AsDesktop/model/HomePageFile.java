package com.automic.dac.asdesktop.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "uploaddata")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HomePageFile {
	
	/**
	*
	*
	* uploadId 
	*/
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "uploadid")
	private long uploadId;
	/**
	*
	*
	* status
	*/
	@Column(name = "status")
	private String status;
	/**
	*
	*
	* filename
	*/
	@Column(name = "filename")
	private String filename;
	/**
	*
	*
	* result
	*/
	@Column(name = "result")
	private String result;
	/**
	*
	*
	* iteration
	*/
	@Column(name = "iteration")
	private int iteration;

	
	
	/**
	*
	*
	* empty Constructor
	*/
	public HomePageFile() {
	super();
	}

	
	/**
	*
	*
	*  Constructor with fields
	*/
	public HomePageFile(final  String status,  final String filename, final String result, final int iteration) {
		super();
		
		this.status = status;
		this.filename = filename;
		this.result = result;
		this.iteration = iteration;
	}



	public long getUploadId() {
		return uploadId;
	}

	public void setUploadId(final long uploadId) {
		this.uploadId = uploadId;
	}

	

	public String getStatus() {
		return status;
	}

	public void setStatus(final String status) {
		this.status = status;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(final String filename) {
		this.filename = filename;
	}

	public String getResult() {
		return result;
	}

	public void setResult(final String result) {
		this.result = result;
	}

	public int getIteration() {
		return iteration;
	}

	public void setIteration(final int iteration) {
		this.iteration = iteration;
	}
	
	
}
