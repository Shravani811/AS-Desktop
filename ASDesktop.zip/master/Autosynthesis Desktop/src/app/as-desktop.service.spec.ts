import { TestBed } from '@angular/core/testing';

import { AsDesktopService } from './as-desktop.service';

describe('AsDesktopService', () => {
  let service: AsDesktopService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AsDesktopService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
