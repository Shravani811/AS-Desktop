package com.automic.dac.asdesktop.script;


/**
*
*
* @author Nischala 
*/
public class ScriptRun {
	
	
	
	/*
	 * public void run(int uploadid, int num) {
	 * 
	 * String fetching = "python" +
	 * "C:\\Users\\nischr\\Desktop\\imp\\java utility\\ASDesktop\\WebContent\\python\\main.py"
	 * ; String[] commandToExecute = new String[]{"cmd.exe", "/c", fetching}; try {
	 * Runtime.getRuntime().exec(commandToExecute); } catch (IOException e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); }
	 * 
	 * }
	 */

}
