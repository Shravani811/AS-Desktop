import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AsDesktopService } from '../as-desktop.service';
import { LoginDetail } from '../data/login-detail';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  searchExpand!: boolean;
  isMenuCollapsed = true;
  userId!:any;
  detail:LoginDetail= new LoginDetail();
  constructor(private router:Router ,private service:AsDesktopService) { }
 profileAction(value:any){
    if(value === 'logout'){
      this.router.navigate(['/login'])
    }
  }
  ngOnInit(): void {
    this.userId = this.service.getUserID();
    console.log(this.userId)
  }
}