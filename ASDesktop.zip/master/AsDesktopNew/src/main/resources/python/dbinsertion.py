import psycopg2
import traceback


def connectDB(pdatabase, pUser, pPassword, pHost, pPort):
    database = psycopg2.connect(database=pdatabase, user=pUser, password=pPassword, host=pHost, port=pPort)
    return (database)


def loadData(pDatabase, pData):
    cursor = pDatabase.cursor()
    #cursor.execute("""TRUNCATE TABLE topicdata""")
    totalRecordsProcessed = 0
    try:
        for i in range(len(pData)):
            try:
                # INSERT
                query = """INSERT INTO topicdata (Ticket_No, Ticket_Type, Ticket_Description, Sample, SolvedWorkgroup, Topic) VALUES(%s,%s,%s,%s,%s,%s)"""

                values = (str(pData.Ticket_No.values[i]), str(pData.Ticket_Type.values[i]), str(pData.Ticket_Description.values[i]),
                          str(pData.Sample.values[i]), str(pData.Solved_Workgroup.values[i]), str(pData.Topic.values[i]))

                cursor.execute(query, values)
                totalRecordsProcessed += 1
                # Ongoing Commit after 100 rows
                if (totalRecordsProcessed % 100 == 0):
                    pDatabase.commit()
                    print(totalRecordsProcessed, 'rows inserted...')

            except Exception as e:
                # print('Some error occured during row injection.')
                print(traceback.format_exc())
                # pDatabase.rollback()
                # cursor.close()
                return (-1)
                #continue
        # Final Commit
        pDatabase.commit()
        cursor.close()
        print('Total', totalRecordsProcessed, ' rows inserted out of ', len(pData))
        print('Successful...!!')
        return (0)
    except Exception as e:
        print(traceback.format_exc())
        print('No rows inserted. Some error occured in database connection.')
        return (-1)
