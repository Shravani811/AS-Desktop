import { LoginDetail } from "./login-detail";


describe('LoginDetail', () => {
  it('should create an instance', () => {
    expect(new LoginDetail()).toBeTruthy();
  });

  
});
