package com.automic.dac.asdesktop;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.automic.dac.asdesktop.controller.LoginPageUserController;
import com.automic.dac.asdesktop.model.TechnologyStack;

@SpringBootTest
public class UnitTestMainScreen {

	@Autowired
	LoginPageUserController controller;
	

	@Test
	public void testTechnologyStack() {
		ResponseEntity<List<TechnologyStack>> technologyStack=controller.gettechnologyStack(45);
		assertThat(technologyStack.getBody().get(0).getTechnology()).isEqualTo("'sap'");		
	}
	
	
	
}
