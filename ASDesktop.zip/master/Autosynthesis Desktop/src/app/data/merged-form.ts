export interface MergedForm{
    mergeGroup:string;
    fromGroup:string;
}