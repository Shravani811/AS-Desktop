package com.automic.dac.asdesktop.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
*
*
* @author Nischala 
*/
@Entity
@Table(name = "loginUser")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginPageUser {
	/**
	*
	*
	* userId
	*/
	@Id
	private String userId;
	/**
	*
	*
	* password
	*/
	private String password;
	
	/**
	*
	*
	* empty Constructor
	*/
	public LoginPageUser() {
	super();
	}
	/**
	*
	*
	* Constructor with fields
	*/
	public LoginPageUser(final String userId, final String password) {
		
		this.userId = userId;
		this.password = password;
	}
	public String getUserId() {
		return userId;
	}
	/**
	*
	*
	* setUserId
	*/
	public void setUserId(final String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	/**
	*
	*
	* setPassword
	*/
	public void setPassword(final String password) {
		this.password = password;
	}
	

}
