package com.automic.dac.asdesktop.errormessage;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;



/**
*
*
* @author Nischala 
*/
public class HomePageExceptionAdvice extends ResponseEntityExceptionHandler {
	/**
	*
	*
	* HomePageExceptionAdvice empty constructor 
	*/
	  public HomePageExceptionAdvice() {
	     super();
			}
	  /**
	  *
	  *
	  * handleMaxSizeException
	  */
	@ExceptionHandler(MaxUploadSizeExceededException.class)
	  public ResponseEntity<HomePageResponseMessage> handleMaxSizeException(final MaxUploadSizeExceededException exc) {
	    return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new HomePageResponseMessage("File too large!"));
	  }
	}
