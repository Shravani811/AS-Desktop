package com.automic.dac.asdesktop;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.automic.dac.asdesktop.controller.LoginPageUserController;
import com.automic.dac.asdesktop.model.TechnologyStack;

@SpringBootTest
class AsDesktopNewApplicationTests {
	
	
	@Autowired
	LoginPageUserController controller;
	

	@Test
	void contextLoads() throws Exception {
		assertThat(controller).isNotNull();
	}

	
	
	
}
