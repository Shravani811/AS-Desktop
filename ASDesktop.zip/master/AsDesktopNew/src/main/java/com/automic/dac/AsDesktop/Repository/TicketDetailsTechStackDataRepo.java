package com.automic.dac.asdesktop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.automic.dac.asdesktop.model.TicketDetailsTechStackData;


/**
*
*
* @author Nischala 
*/
@Repository
public interface TicketDetailsTechStackDataRepo extends JpaRepository<TicketDetailsTechStackData, Long>{
	/**
	*
	*
	*  get list of TicketDetailsTechStackData object by userid
	*/
		List<TicketDetailsTechStackData>findByUploadid(int uploadid);
	

}
