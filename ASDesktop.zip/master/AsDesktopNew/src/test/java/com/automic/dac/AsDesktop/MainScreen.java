package com.automic.dac.asdesktop;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.automic.dac.asdesktop.model.TicketDetailsNgramTable;
import com.automic.dac.asdesktop.model.TicketDetailsTechdata;
import com.automic.dac.asdesktop.model.TicketDetailsTopicdata;
import com.automic.dac.asdesktop.repository.TicketDetailsNgramTableRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsTechdataRepo;
import com.automic.dac.asdesktop.repository.TicketDetailsTopicdataRepo;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class MainScreen {

	@Autowired
	TicketDetailsNgramTableRepo ngramTableRepo;

	@Autowired
	TicketDetailsTopicdataRepo topicdataRepo;

	@Autowired
	TicketDetailsTechdataRepo techdataRepo;

	@Test
	@Order(1)
	public void testReadAllNgramTable() {
		List<TicketDetailsNgramTable> list = ngramTableRepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	@Order(2)
	public void testReadAllTopicData() {
		List<TicketDetailsTopicdata> list = topicdataRepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	@Order(3)
	public void testReadAllTechnologyStack() {
		List<TicketDetailsNgramTable> list = ngramTableRepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	@Order(4)
	public void testReadAllTechdata() {
		List<TicketDetailsTechdata> list = techdataRepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
